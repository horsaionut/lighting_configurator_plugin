<?php

if (!defined('ABSPATH')) {
    exit;
}

class Lighting_Configurator_Deactivator
{
    public static function deactivate()
    {
        // Reserved for future cleanup tasks.
    }
}
